import { Alert, AlertTitle, AlertDescription } from "./components/ui/alert";
import { Button } from "./components/ui/button";

import { AlertTriangleIcon, RefreshCwIcon } from "lucide-react";

export const ErrorFallback = ({ error, resetErrorBoundary }) => {
  // When encountering an error in the development mode, rethrow it and don't display the boundary.
  // The parent UI will take care of showing a more helpful dialog.
  if (import.meta.env.DEV) throw error;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Alert variant="destructive" className="mb-6 rounded-none border-2">
          <AlertTriangleIcon />
          <AlertTitle className="font-mono uppercase tracking-wider">Runtime Error</AlertTitle>
          <AlertDescription className="font-mono text-sm">
            Something unexpected happened while running the application. The error details are shown below. Contact the spark author and let them know about this issue.
          </AlertDescription>
        </Alert>
        
        <div className="bg-card border-2 border-foreground p-4 mb-6">
          <h3 className="font-semibold text-sm text-muted-foreground mb-2 font-mono uppercase tracking-wider">Error Details:</h3>
          <pre className="text-xs text-destructive bg-muted/50 p-3 border border-border overflow-auto max-h-32 font-mono">
            {error.message}
          </pre>
        </div>
        
        <Button 
          onClick={resetErrorBoundary} 
          className="w-full rounded-none border-2 font-mono uppercase tracking-wider"
          variant="outline"
        >
          <RefreshCwIcon />
          Try Again
        </Button>
      </div>
    </div>
  );
}
