# AeThex Programming Language

**Write once. Build everywhere. Connect all realities.**

AeThex is a domain-specific programming language designed for cross-platform metaverse development. Write your game logic once in AeThex, then deploy it across Roblox, UEFN/Fortnite, Unity, VRChat, Spatial, and the web.

```aethex
journey AuthenticateUser(traveler) {
    platform: all
    
    when traveler.verified {
        sync traveler.passport across [roblox, uefn, web]
        notify "Identity confirmed across realities"
    }
}
```

Compiles to JavaScript, Lua (Roblox), Blueprint (UEFN), and C# (Unity).

---

## Quick Start

```bash
# Clone the repository
git clone https://github.com/yourusername/aethex-lang.git
cd aethex-lang

# Compile an example
node aethex-compiler.js examples/passport-mvp.aethex

# Run the compiled code
node examples/passport-mvp.js
```

---

## Why AeThex?

**The Problem:** Building cross-platform games means writing the same logic multiple times in different languages.

**The Solution:** Write once in AeThex. Deploy everywhere.

---

## Language Features

- 🌐 **Cross-Platform** - Roblox, UEFN, Unity, VRChat, Spatial, Web
- 🔄 **State Sync** - Automatic cross-platform data synchronization
- 🎫 **Universal Identity** - Passport system for player authentication
- 🛡️ **Compliance** - Built-in COPPA/FERPA directives
- ⚡ **Modern Syntax** - Readable, declarative code

---

## Syntax Overview

### Realities (Execution Contexts)
```aethex
reality AeThex_Passport {
    type: "identity_layer"
    platforms: all
}
```

### Passports (Cross-Platform State)
```aethex
passport user_identity {
    username: "MrPiglr"
    verified: true
}
```

### Journeys (Functions)
```aethex
journey AuthenticateUser(traveler) {
    platform: all
    sync traveler.passport across [roblox, uefn, web]
    notify "Welcome back!"
}
```

### Workflows (Multi-Stage Processes)
```aethex
workflow OnboardNewUser {
    stage welcome {
        notify "Welcome to AeThex!"
    }
}
```

See [SPEC.md](SPEC.md) for complete language specification.

---

## Current Status

**Working (v0.1.0 MVP):**
- ✅ JavaScript compilation
- ✅ Core syntax (reality, passport, journey, when, sync)
- ✅ Runtime system
- ✅ Cross-platform state management

**Coming Soon:**
- 🚧 Lua compilation (Roblox)
- 🚧 Blueprint compilation (UEFN)
- 🚧 C# compilation (Unity)
- 🚧 VS Code extension
- 🚧 Online playground

---

## Examples

- `examples/passport-mvp.aethex` - Universal identity system
- `examples/test-simple.aethex` - Basic syntax demo

---

## Documentation

- [Full Language Spec](SPEC.md)
- [Examples](examples/)

---

## Built By

**Anderson (MrPiglr)** - Founder & CTO of AeThex
- 11 years Roblox development experience
- RDC panelist & Beta Tester
- Building the operating system for the metaverse

---

## License

MIT - See [LICENSE](LICENSE)

---

**AeThex Language: The universal language for metaverse development.** 🌐
